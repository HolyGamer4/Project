import os
import sys
import pygame

pygame.init()
pygame.key.set_repeat(200, 70)
pygame.display.set_caption('Elf in the wood')

FPS = 60
WIDTH = 500
HEIGHT = 500
STEP = 10

screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

player = None
all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
grasses = []
boxes = []
coin = 0
enemies = []

# для переключения между уровнями
global level1
global level2
global level3
level1 = False
level2 = False
level3 = False
global flag
global running
running = True
flag = True
level1 = False


# загрузка всех картинок
def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image = image.convert_alpha()

    if color_key is not None:
        if color_key is -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    return image


# для анимации персонажа(в каком направлении он ходит)
left = False
right = False
up = False
down = False
left1 = False
right1 = False
up1 = False
down1 = False
animCount = 0
# картинки для анимации персонажа
walkRight = [load_image('Elf_right10.png'), load_image('Elf_right9.png'),
             load_image('Elf_right8.png'), load_image('Elf_right7.png'),
             load_image('Elf_right6.png'), load_image('Elf_right5.png'),
             load_image('Elf_right4.png'), load_image('Elf_right3.png'),
             load_image('Elf_right2.png'), load_image('Elf_right1.png')]
walkLeft = [load_image('Elf_left1.png'), load_image('Elf_left2.png'),
            load_image('Elf_left3.png'), load_image('Elf_left4.png'),
            load_image('Elf_left5.png'), load_image('Elf_left6.png'),
            load_image('Elf_left7.png'), load_image('Elf_left8.png'),
            load_image('Elf_left9.png'), load_image('Elf_left10.png')]
stay = [load_image('Elf_straight02.png'), load_image('Elf_straight03.png'),
        load_image('Elf_straight04.png')]
stay_right = [load_image('Elf_right01.png'), load_image('Elf_right02.png'),
              load_image('Elf_right03.png'), load_image('Elf_right04.png')]
stay_left = [load_image('Elf_left01.png'), load_image('Elf_left02.png'),
             load_image('Elf_left03.png'), load_image('Elf_left04.png')]
walkBack = [load_image('Elf_back1.png'), load_image('Elf_back2.png'),
            load_image('Elf_back3.png'), load_image('Elf_back4.png'),
            load_image('Elf_back5.png'), load_image('Elf_back6.png'),
            load_image('Elf_back7.png'), load_image('Elf_back8.png'),
            load_image('Elf_back9.png'), load_image('Elf_back10.png')]
walkStraight = [load_image('Elf_straight1.png'),
                load_image('Elf_straight2.png'),
                load_image('Elf_straight3.png'),
                load_image('Elf_straight4.png'),
                load_image('Elf_straight5.png'),
                load_image('Elf_straight6.png'),
                load_image('Elf_straight7.png'),
                load_image('Elf_straight8.png'),
                load_image('Elf_straight9.png'),
                load_image('Elf_straight10.png')]


# загрузка уровня из файла
def load_level(filename):
    filename = "data/" + filename
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]

    max_width = max(map(len, level_map))

    return list(map(lambda x: x.ljust(max_width, '.'), level_map))


# генерация уровня из текстового файла
def generate_level(level):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                grasses.append(Tile('empty', x, y))
            elif level[y][x] == '8':
                grasses.append(Tile('road', x, y))
            elif level[y][x] == '#':
                boxes.append(Tile('tree', x, y))
            elif level[y][x] == '2':
                boxes.append(Tile('tree2', x, y))
            elif level[y][x] == '7':
                boxes.append(Tile('stump', x, y))
            elif level[y][x] == '0':
                boxes.append(Tile('finish', x, y))
            elif level[y][x] == 'e':
                enemies.append(Tile('tree', x, y, 'e'))
            elif level[y][x] == '1':
                boxes.append(Tile('flowers', x, y))
            elif level[y][x] == '3':
                boxes.append(Tile('mushrooms1', x, y))
            elif level[y][x] == '4':
                boxes.append(Tile('mushrooms2', x, y))
            elif level[y][x] == '6':
                boxes.append(Tile('well', x, y))
            elif level[y][x] == '@':
                grasses.append(Tile('empty', x, y))
                new_player = Player(x, y)
    return new_player, x, y


# закрытие
def terminate():
    pygame.quit()
    sys.exit


# начальный экран
def start_screen():
    global running
    fon = pygame.transform.scale(load_image('fon3.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    rules = pygame.transform.scale(load_image('rules.png'), (200, 100))
    screen.blit(rules, (150, 80))
    exit1 = pygame.transform.scale(load_image('exit.png'), (200, 100))
    screen.blit(exit1, (150, 350))
    start = pygame.transform.scale(load_image('start.png'), (250, 130))
    screen.blit(start, (127, 200))
    flag = True
    while flag:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                flag = False
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                if 127 <= pygame.mouse.get_pos()[0] <= 377 and 200 <= \
                        pygame.mouse.get_pos()[1] <= \
                        330 and pygame.mouse.get_pressed():
                    level_screen()
                    flag = False
                    return
                elif 150 <= pygame.mouse.get_pos()[0] <= 350 and 80 <= \
                        pygame.mouse.get_pos()[1] <= \
                        180 and pygame.mouse.get_pressed():
                    rules_screen()
                    flag = False
                elif 150 <= pygame.mouse.get_pos()[0] <= 350 and 350 <= \
                        pygame.mouse.get_pos()[1] <= \
                        450 and pygame.mouse.get_pressed():
                    running = False
                    flag = False
        pygame.display.flip()
        clock.tick(FPS)


# магазин
def shop():
    global coin
    global STEP
    c = True
    fon = pygame.transform.scale(load_image('shop.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    intro_text = ["У вас есть",
                  str(coin) + ' руб.',
                  "На данный момент можно купить",
                  'только усиление скорости.']
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)
    screen.blit(pygame.transform.scale(load_image('up.png'),
                                       (200, 200)), (50, 300))
    screen.blit(pygame.transform.scale(load_image('down.png'),
                                       (200, 200)), (250, 300))
    while c:
        screen.blit(fon, (0, 0))
        intro_text = ["У вас есть",
                      str(coin) + ' руб.',
                      "На данный момент можно купить",
                      'только усиление скорости.',
                      'Пока все монеты не потрачены',
                      'выход невозможен.']
        font = pygame.font.Font(None, 30)
        text_coord = 50
        for line in intro_text:
            string_rendered = font.render(line, 1, pygame.Color('black'))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 10
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)
            screen.blit(pygame.transform.scale(load_image('up.png'),
                                               (200, 200)), (50, 300))
            screen.blit(pygame.transform.scale(load_image('down.png'),
                                               (200, 200)), (250, 300))
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN or event.type == \
                    pygame.MOUSEBUTTONDOWN:
                if 50 <= pygame.mouse.get_pos()[0] <= 250 \
                        and 150 <= pygame.mouse.get_pos()[1] <= \
                        500 and pygame.mouse.get_pressed() and int(coin) >= 1:
                    coin -= 1
                    STEP += 1
                elif 250 <= pygame.mouse.get_pos()[0] <= 375 and 150 <= \
                        pygame.mouse.get_pos()[1] <= 500 and \
                        pygame.mouse.get_pressed() \
                        and int(coin) >= 1:
                    coin -= 1
                    STEP -= 1
                if coin == 0 and event.type == pygame.MOUSEBUTTONDOWN:
                    start_screen()
                    c = False
        pygame.display.flip()
        clock.tick(FPS)


# экран выбора уровня
def level_screen(lev=False):
    global running
    global b
    global level1
    global level2
    global level3
    b = True
    fon1 = pygame.transform.scale(load_image('fon3.png'), (WIDTH, HEIGHT))
    screen.blit(fon1, (0, 0))
    level1_im = pygame.transform.scale(load_image('level1.png'), (200, 186))
    screen.blit(level1_im, (-20, 150))
    screen.blit(pygame.transform.scale(load_image('level2.png'),
                                       (200, 186)), (150, 150))
    screen.blit(pygame.transform.scale(load_image('level3.png'),
                                       (200, 186)), (320, 150))
    screen.blit(pygame.transform.scale(load_image('exit.png'),
                                       (200, 100)), (300, 350))
    screen.blit(pygame.transform.scale(load_image('shop.png'),
                                       (200, 80)), (50, 360))
    while b:
        if lev == 'level11':
            b = False
            level(load_level('map.txt'))
            return
        elif lev == 'level22':
            b = False
            level(load_level('map2.txt'))
            return
        elif lev == 'level33':
            b = False
            level(load_level('map3.txt'))
            return
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                flag = False
            elif event.type == pygame.KEYDOWN or event.type == \
                    pygame.MOUSEBUTTONDOWN:
                if 15 <= pygame.mouse.get_pos()[0] <= 145 and 158 <=\
                        pygame.mouse.get_pos()[1] <= \
                        330 and pygame.mouse.get_pressed():
                    b = False
                    level1 = True
                    # lev = 'level11'
                    level(load_level('map.txt'))
                    return
                elif 186 <= pygame.mouse.get_pos()[0] <= 318 and 158 <= \
                        pygame.mouse.get_pos()[1] <= \
                        330 and pygame.mouse.get_pressed():
                    b = False
                    level2 = True
                    level(load_level('map2.txt'))
                    return
                elif 355 <= pygame.mouse.get_pos()[0] <= 487 and 158 <= \
                        pygame.mouse.get_pos()[1] <= \
                        330 and pygame.mouse.get_pressed():
                    b = False
                    level3 = True
                    level(load_level('map3.txt'))
                    return
                elif 300 <= pygame.mouse.get_pos()[0] <= 494 and 360 <= \
                        pygame.mouse.get_pos()[1] <= \
                        440 and pygame.mouse.get_pressed():
                    start_screen()
                    b = False
                elif 50 <= pygame.mouse.get_pos()[0] <= 250 and 360 <= \
                        pygame.mouse.get_pos()[1] <= \
                        440 and pygame.mouse.get_pressed():
                    shop()
                    b = False
        pygame.display.flip()
        clock.tick(FPS)


# правила игры
def rules_screen():
    global a
    a = True
    fon1 = pygame.transform.scale(load_image('w_rules.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon1, (0, 0))
    while a:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN or event.type == \
                    pygame.MOUSEBUTTONDOWN:
                a = False
                start_screen()
        pygame.display.flip()
        clock.tick(FPS)


# победа или поражение в уровне
def game_over(end):
    global running
    a = True
    if end == 'bad':
        fon1 = pygame.transform.scale(load_image('game_over.jpg'),
                                      (WIDTH, HEIGHT))
    else:
        fon1 = pygame.transform.scale(load_image('game_over2.jpg'),
                                      (WIDTH, HEIGHT))
    screen.blit(fon1, (0, 0))
    while a:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    a = False
                    level_screen()
        pygame.display.flip()
        clock.tick(FPS)


# препятствия
tile_images = {'flowers': load_image('flowers.png'),
               'empty': load_image('grass.png'),
               'mushrooms1': load_image('mushrooms1.png'),
               'mushrooms2': load_image('mushrooms2.png'),
               'finish': load_image('dead.png'),
               'tree': load_image('tree.png'),
               'well': load_image('well.png'),
               'tree2': load_image('tree2.png'),
               'road': load_image('road.png'),
               'stump': load_image('stump.png')}
player_image = load_image('Elf_straight01.png')

tile_width = tile_height = 50


# класс препятствий
class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y, enemy=False):
        super().__init__(tiles_group, all_sprites)
        self.pos_x = pos_x
        self.flag = True
        self.tile_type = tile_type
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(tile_width * pos_x,
                                               tile_height * pos_y)


# класс игрока
class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = player_image
        self.pos_x = pos_x
        self.rect = self.image.get_rect().move(tile_width * pos_x + 15,
                                               tile_height * pos_y + 5)


# класс жизней и монет
class Life(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y, count):
        super().__init__(player_group)
        self.image = load_image('life.png')
        self.pos_x = pos_x
        self.coins = 0
        self.count = count
        self.rect = self.image.get_rect().move(tile_width * pos_x + 15,
                                               tile_height * pos_y + 5)


# кнопка для того, чтобы начать уровень заново
class Replay(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y, count):
        super().__init__(player_group)
        self.image = pygame.transform.scale(load_image('replay.png'),
                                            (100, 40))
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.count = count
        self.rect = self.image.get_rect().move(tile_width * pos_x + 15,
                                               tile_height * pos_y + 5)
        self.mask = pygame.mask.from_surface(self.image)

    def point_collide(self, point):
        if 52 <= point[0] <= 160 and 35 <= point[1] <= 65:
            n = int(point[0])
            m = int(point[1])
            n -= self.rect[0]
            m -= self.rect[1]
            return self.mask.get_at((n, m))


# класс камеры
class Camera:
    def __init__(self, field_size):
        self.dx = 0
        self.dy = 0
        self.field_size = field_size

    def apply(self, obj):
        obj.rect.x += self.dx
        if obj.rect.x < -obj.rect.width:
            obj.rect.x += (self.field_size[0] + 1) * obj.rect.width
        if obj.rect.x >= (self.field_size[0]) * obj.rect.width:
            obj.rect.x += -obj.rect.width * (1 + self.field_size[0])
        obj.rect.y += self.dy
        if obj.rect.y < -obj.rect.height:
            obj.rect.y += (self.field_size[1] + 1) * obj.rect.height
        if obj.rect.y >= (self.field_size[1]) * obj.rect.height:
            obj.rect.y += -obj.rect.height * (1 + self.field_size[1])

    def update(self, target):
        self.dx = -(target.rect.x + target.rect.w // 2 - WIDTH // 2)
        self.dy = -(target.rect.y + target.rect.h // 2 - HEIGHT // 2)


# отрисовка уровня
def drawLevel():
    global animCount
    global level1
    global level2
    global level3
    global FPS
    # global life

    count1 = 2
    count2 = 20
    if level1:
        screen.fill(pygame.Color(35, 157, 26))
    elif level2:
        screen.fill(pygame.Color(183, 183, 0))
    elif level3:
        screen.fill(pygame.Color(35, 157, 26))

    if life.count == 1:
        life.image = load_image('life.png')
    elif life.count == 2:
        life.image = load_image('life2.png')
    elif life.count == 3:
        life.image = load_image('life3.png')

    # screen.fill(pygame.Color(35, 157, 26))
    tiles_group.draw(screen)

    if animCount + count1 >= FPS:
        animCount = 0

    if left:
        player.image = walkLeft[animCount // count2]
        animCount += count1
    elif right:
        player.image = walkRight[animCount // count2]
        animCount += count1
    elif up:
        player.image = walkBack[animCount // count2]
        animCount += count1
    elif down:
        player.image = walkStraight[animCount // count2]
        animCount += count1
    if down1:
        player.image = stay[animCount // count2]
        animCount += count1
    elif right1:
        player.image = stay_right[animCount // count2]
        animCount += count1
    elif left1:
        player.image = stay_left[animCount // count2]
        animCount += count1

    collision(player, enemies)

    for i in range(len(enemies)):
        if enemies[i].flag and not collision(enemies[i], grasses):
            enemies[i].rect.x += 10
        else:
            enemies[i].rect.x -= 10
        if collision(enemies[i], boxes):
            enemies[i].flag = not enemies[i].flag

    camera.update(player)

    for sprite in all_sprites:
        camera.apply(sprite)
        life.rect = (player.rect.x + 160, player.rect.y - 210)
        replay.rect = (player.rect.x - 200, player.rect.y - 210)

    player_group.draw(screen)

    pygame.display.flip()


# всё, связанное с столкновением игрока с препятствиями,
# препятствий между собой и нажатием на некоторые кнопки
def collision(player, group):
    global coins
    global coin
    global life
    global boxes
    global grasses
    global enemies
    global all_sprites
    global tiles_group
    global player_group
    global level1
    global level2
    global level3
    for i in range(len(group)):
        if pygame.sprite.collide_mask(player, group[i]):
            if group[i].tile_type == 'mushrooms1':
                boxes[i].image = load_image('grass.png')
                del group[i]
                #
                # tiles_group.draw(screen)
                life.count -= 1
                if life.count == 0:
                    all_sprites = pygame.sprite.Group()
                    tiles_group = pygame.sprite.Group()
                    player_group = pygame.sprite.Group()
                    grasses = []
                    boxes = []
                    enemies = []
                    level1 = False
                    level2 = False
                    level3 = False
                    life.count = 3
                    game_over('bad')
            elif group[i].tile_type == 'tree' and group == enemies:
                enemies[i].image = load_image('grass.png')
                del group[i]
                #
                # tiles_group.draw(screen)
                life.count -= 1
                if life.count == 0:
                    all_sprites = pygame.sprite.Group()
                    tiles_group = pygame.sprite.Group()
                    player_group = pygame.sprite.Group()
                    grasses = []
                    boxes = []
                    enemies = []
                    level1 = False
                    level2 = False
                    level3 = False
                    life.count = 3
                    game_over('bad')
            elif group[i].tile_type == 'finish':
                all_sprites = pygame.sprite.Group()
                tiles_group = pygame.sprite.Group()
                player_group = pygame.sprite.Group()
                coins.coins += 1
                coin += 1
                grasses = []
                boxes = []
                enemies = []
                level1 = False
                level2 = False
                level3 = False
                life.count = 3
                game_over('good')
            elif group[i].tile_type == 'mushrooms2' and life.count <= 2:
                boxes[i].image = load_image('grass.png')
                del group[i]
                #
                # tiles_group.draw(screen)
                life.count += 1
            elif group[i].tile_type == 'well':
                boxes[i].image = load_image('grass.png')
                del group[i]
                coins.coins += 1
                coin += 1
                #
                # tiles_group.draw(screen)

            return True


# уровень в целом
def level(level):
    global camera
    global running
    global player
    global right1
    global down1
    global left1
    global up
    global up1
    global right
    global down
    global left
    global life
    global replay
    global exit_of_level
    global life
    global coins
    global boxes
    global grasses
    global enemies
    global all_sprites
    global tiles_group
    global player_group
    global level1
    global level2
    global level3
    player, level_x, level_y = generate_level(level)
    life = Life(player.rect.x + 100, player.rect.y - 100, 3)
    coins = Life(player.rect.x - 150, player.rect.y - 100, 3)
    coins.image = load_image('coin.png')
    camera = Camera((level_x, level_y))
    replay = Replay(player.rect.x - 200, player.rect.y - 100, 3)

    right1 = False
    down1 = False
    left1 = False
    up = False
    up1 = False
    right = False
    down = False
    left = False
    while running:

        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                click_position = event.pos
                if replay.point_collide(click_position) and level1:
                    all_sprites = pygame.sprite.Group()
                    tiles_group = pygame.sprite.Group()
                    player_group = pygame.sprite.Group()
                    grasses = []
                    boxes = []
                    enemies = []
                    life.count = 3
                    # level1 = True
                    level_screen('level11')
                elif replay.point_collide(click_position) and level2:
                    all_sprites = pygame.sprite.Group()
                    tiles_group = pygame.sprite.Group()
                    player_group = pygame.sprite.Group()
                    grasses = []
                    boxes = []
                    enemies = []
                    life.count = 3
                    # level2 = True
                    level_screen('level22')
                elif replay.point_collide(click_position) and level3:
                    all_sprites = pygame.sprite.Group()
                    tiles_group = pygame.sprite.Group()
                    player_group = pygame.sprite.Group()
                    grasses = []
                    boxes = []
                    enemies = []
                    life.count = 3
                    # level3 = True
                    level_screen('level33')
                    
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                left1 = False
                right1 = False
                up1 = False
                down1 = False
                if event.key == pygame.K_LEFT:
                    player.rect.x -= STEP
                    if not collision(player, boxes):
                        player.rect.x -= STEP
                        left = True
                    player.rect.x += STEP
                if event.key == pygame.K_RIGHT:
                    player.rect.x += STEP
                    if not collision(player, boxes):
                        player.rect.x += STEP
                        right = True
                    player.rect.x -= STEP
                if event.key == pygame.K_UP:
                    player.rect.y -= STEP
                    if not collision(player, boxes):
                        player.rect.y -= STEP
                        up = True
                    player.rect.y += STEP
                if event.key == pygame.K_DOWN:
                    player.rect.y += STEP
                    if not collision(player, boxes):
                        player.rect.y += STEP
                        down = True
                    player.rect.y -= STEP
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT:
                    left1 = True
                elif event.key == pygame.K_RIGHT:
                    right1 = True
                elif event.key == pygame.K_DOWN:
                    down1 = True
                elif event.key == pygame.K_UP:
                    up1 = True
                left = False
                right = False
                up = False
                down = False
            elif event.type != pygame.KEYDOWN and event.type != pygame.KEYUP \
                    and event.type != pygame.MOUSEMOTION:
                down1 = True

        drawLevel()


# основной код
if __name__ == '__main__':
    pygame.mixer.init()
    pygame.mixer.music.load('08236.mp3')
    pygame.mixer.music.play(-1)
    start_screen()
    terminate()
